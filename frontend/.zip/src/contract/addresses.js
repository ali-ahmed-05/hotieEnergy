
 export const staking_addr = "0x1D8D70AD07C8E7E442AD78E4AC0A16f958Eba7F0"
 export const hestoken_addr = "0x742489F22807ebB4C36ca6cD95c3e1C044B7B6c8"
 export const router_addr = "0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D"
